import React from 'react';

const ListComponent = (props) => {

  return (

    <div className="Component">

      <h2>{props.text}</h2>

    </div>

  );
};

export { ListComponent };