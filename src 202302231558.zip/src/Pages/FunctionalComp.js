import React from 'react';

export default function FunctionalComp(){
    return(
        <p>Functional Component Area</p>
    ) 
}

