import React from 'react'

const about = () => {
    return (
        <div>
            <h5>This Page is made for learning React with Router, Bootstrap</h5>
        </div>
    )
}

export default about