import '.././App.css';

function Home() {
  return (
    <div className="Home">
      <h1>Home Page</h1>
    </div>
  );
}

export default Home;