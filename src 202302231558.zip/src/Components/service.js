import React from 'react'

const service = () => {
    return (
        <div>
            <h1>Service Page</h1>
        </div>
    )
}

export default service
